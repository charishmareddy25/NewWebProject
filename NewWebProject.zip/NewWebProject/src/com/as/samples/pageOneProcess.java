package com.as.samples;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class pageOneProcess
 */
public class pageOneProcess extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
    	String name=request.getParameter("name");
    	String address=request.getParameter("address");
    	String phonenumber=request.getParameter("phonenumber");
    	
    	System.out.println("The Name is:"+name);
    	System.out.println("The Address is:"+address);
    	System.out.println("The Phone Number is:"+phonenumber);
   
    	request.getSession().setAttribute("name", name);
    	request.getSession().setAttribute("address", address);
    	request.getSession().setAttribute("phonenumber", phonenumber);
    	
    	response.sendRedirect("html/pageTwo.html");
    	 

    }

}
